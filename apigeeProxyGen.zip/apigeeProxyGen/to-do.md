## Things to be done
- Exception handling
- Integrate the CLI on Jenkins
	- May be a common utility job that folks can utilize

