package com.example.apigee.proxygen.service;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.apigee.proxygen.bean.ServiceDetailsBean;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.PathItem.HttpMethod;
import io.swagger.v3.oas.models.responses.ApiResponse;

@Service
public class APIGEETestCaseGenService {
	
	@Value("${config.test.generation.enabled}")
	private boolean enabled;
	
	Logger logger = LoggerFactory.getLogger(APIGEETestCaseGenService.class);
	
	public void generateTestsFromOAS(Path workDirectory, OpenAPI openAPI) throws Exception	{
		if (!enabled)	{
			logger.info("Test generation is disabled.");
			return ;
		}
		
		Path testDir = Paths.get(workDirectory.toAbsolutePath().toString() 
				+ "/test") ;
		Files.createDirectories(testDir) ;
		
		openAPI.getPaths()
			.entrySet()
			.stream()
			.forEach(e -> createTestArtifacts(e, testDir));
	}
	


	private void createTestArtifacts(Entry<String, PathItem> uri, Path root) {
		String path = uri.getKey() ;
		uri.getValue().readOperationsMap()
			.entrySet()
			.stream()
			.forEach(pathItem -> {
				try {
					createTestArtifactsForPath(root, path, pathItem);
				} catch (Exception e) {
					logger.error("Unable to generate Test Artifacts", e);
				}
			});
	}
	
	private void createTestArtifactsForPath(Path root, String path, Entry<HttpMethod, 
			Operation> op) throws Exception	{
		ServiceDetailsBean bean = getOperations(path, op);
		createFeatures(root, path, op.getKey(), bean);
		createTestFixtures(root, path, op.getKey(), bean);
	}

	private void createTestFixtures(Path root, String path, HttpMethod key, 
			ServiceDetailsBean bean) throws Exception {
		String resource = path.substring(path.lastIndexOf("/") + 1) ;
		String featureName = resource + "_" + key  ;
		File resultFile = new File(root.toFile(), featureName + ".json") ;
		logger.info("Creating file "+ resultFile);
		
		Map<String, Object> headers = bean.getHeaders() ;
		Map<String, Object> params = bean.getParameters() ;
		Object req = bean.getRequest() ;
		
		String testData = bean.getResponses()
			.entrySet()
			.stream()
			.map(e -> createTestDataForStatusCode(path, key, 
					headers, params, req, e))
			.flatMap(e -> e.stream())
			.collect(Collectors.joining(",\n", "{", "}"));
		
		ObjectMapper mapper = new ObjectMapper() ;
		JsonNode node = mapper.readTree(testData) ;
		
		mapper.writerWithDefaultPrettyPrinter().writeValue(resultFile, node);
		
	}

	private List<String> createTestDataForStatusCode(String path, 
			HttpMethod method, Map<String, Object> headers, 
				Map<String, Object> params, Object req,
				Entry<String, Map<String, Object>> entry) {
		String httpCode = entry.getKey() ;
		
		return entry.getValue().entrySet()
			.stream()
			.map(e -> createTestDataForScenario(path, method, httpCode, 
					headers, params, req, e))
			.collect(Collectors.toList());
		
	}


	private String createTestDataForScenario(String path, HttpMethod method, 
			String httpCode,  Map<String, Object> headers, 
			Map<String, Object> params, Object req, Entry<String, Object> entry) {
		StringBuilder sb = new StringBuilder("\"") ;
		
		sb.append(httpCode) .append("_")
			.append(entry.getKey()).append("\": {\"uri_value\": \"")
			.append(getUri(path, params))
			.append("\",\"http_response_code\":")
			.append(httpCode);
		
		if (!headers.isEmpty())	{
			sb.append(",\"headers\":");
			sb.append(headers.entrySet().stream()
				.map(e -> "\"" + e.getKey() + "\" : \"" + e.getValue() + "\"")
				.collect(Collectors.joining(",", "{", "}")));
		}
		
		if (req != null)	{
			sb.append(",\"request\":").append(req);
		}
		
		if (entry.getValue() != null)	{
			sb.append(",\"response_verify\":").append(entry.getValue());
		}
		sb.append("}") ;
		return sb.toString();
	}



	private String getUri(String path, Map<String, Object> params) {
		if (params.isEmpty())	{
			return path ;
		}
		return params.entrySet()
				.stream().map(e -> e.getKey() + "=" + e.getValue())
				.collect(Collectors.joining("&", path + "?", "")) ;
	}



	private void createFeatures(Path root, String path, HttpMethod key, 
			ServiceDetailsBean bean) throws Exception {
		String resource = path.substring(path.lastIndexOf("/") + 1) ;
		String featureName = resource + "_" + key  ;
		File resultFile = new File(root.toFile(), featureName + ".feature") ;
		logger.info("Creating file "+ resultFile);
		
		StringBuilder sb = new StringBuilder("Feature: ")
				.append(path.replaceAll("/", " "))
				.append(" ").append(key).append(" validation\n")
				.append("  Scenario Outline: ")
				.append(path.replaceAll("/", " "))
				.append(" ").append(key).append(" validation\n")
				.append("\n#Below sections calls ").append(resource)
				.append(" ").append(key)
				.append("\n    Given I make ").append(key)
				.append(" service call for \"<servicename>\" and with an access token with below request details \"<requestdata>\"")
				.append("\n    When response is an \"object\"")
				.append("\n    Then I verify \"<servicename>\" service response to have expected values\n\n")
				.append("   Examples:\n  | servicename | requestdata |\n") ;
		
		bean.getResponses()
			.entrySet()
			.stream()
			.forEach(e -> createTest(sb, resource, featureName, e));
				
		FileUtils.writeStringToFile(resultFile, sb.toString(), Charset.defaultCharset());
	}

	private StringBuilder createTest(StringBuilder sb, String resource, String featureName, 
			Entry<String, Map<String, Object>> responses) {
		String code = responses.getKey() ;
		responses.getValue()
			.entrySet()
			.stream()
			.forEach(res -> sb.append("  #| ").append(resource)
								.append(" | file==").append(featureName)
								.append(".json;test==").append(code)
								.append("_").append(res.getKey()).append("|\n"));
		
		return sb;
	}

	private ServiceDetailsBean getOperations(String path, Entry<HttpMethod, Operation> op) {
		
		ServiceDetailsBean bean = new ServiceDetailsBean(path) ;
		
		bean.setMethod(op.getKey());
		bean.setHeaders(getParameters("header", op.getValue()));
		bean.setParameters(getParameters("query", op.getValue()));
		bean.setRequest(getRequestBody(op.getValue()));
		bean.setResponses(getResponses(op.getValue()));
		
		return bean;
	}

	private Map<String, Map<String, Object>> getResponses(Operation op) {
		return op.getResponses().entrySet()
			.stream()
			.collect(Collectors.toMap(Map.Entry::getKey, e -> getResponseMap(e.getValue()))) ;
	}
	
	private Map<String, Object> getResponseMap(ApiResponse resp) {
		return resp.getContent().values()
			.stream()
			.filter(m -> m.getExamples() != null)
			.flatMap(m -> m.getExamples().entrySet().stream())
			.collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue().getValue())) ;
	}

	private Object getRequestBody(Operation op) {
		if (op.getRequestBody() != null && op.getRequestBody().getContent() != null
				&& op.getRequestBody().getContent().get("application/json") != null)	{
			return op.getRequestBody().getContent().get("application/json").getExample() ;
		}
		return null;
	}

	private Map<String, Object> getParameters(final String type, Operation op) {
		return op.getParameters()
			.stream()
			.filter(p -> type.equals(p.getIn()))
			.collect(Collectors.toMap(p -> p.getName(), p -> p.getExample()));
	}


}
