package com.example.apigee.proxygen.service;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.*;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

@Service
public class JenkinsConfigService {

	@Value("${config.jenkins.authToken}")
	private String authToken;

	@Value("${config.jenkins.url.createItem}")
	private String createItemUrl;

	@Value("${config.jenkins.url.pipelineScan}")
	private String pipelineScanUrl;

	@Value("${config.jenkins.host}")
	private String jenkinsHost;
	
	@Value("${config.jenkins.enabled}")
	private boolean jenkinsEnabled;

	@Autowired
	private CommonService commonService;

	Logger logger = LoggerFactory.getLogger(JenkinsConfigService.class);

	public void generateJenkinsConfig() throws Exception {

		if(jenkinsEnabled) {
			logger.info("======================================================");
			logger.info("Starting Jenkins integration");

			Map<String, Object> proxyMetadata = commonService.getProxyMetadata();
			String proxyName = commonService.getProxyName();
			String workDirectory = commonService.getWorkDirectory().toAbsolutePath().toString();

			logger.info("     ProxyName: " + proxyName);
			logger.info("     WorkDirectory:" + workDirectory);

			// Copy the jenkinsConfig template to workdir/jenkins-config
			untemplatize(proxyName, workDirectory, proxyMetadata);

			// Make the API call to Jenkins
			createJenkinsPipeline(proxyName, workDirectory);
			// Make the API call to Scan the pipeline
			triggerJenkinsPipelineScan(proxyName);

			logger.info("Jenkins Pipeline creation is complete");
			logger.info("====================================================== \n");
		} else {
			logger.info("Jenkins integration is not enabled.");
		}
	}

	private void createJenkinsPipeline(String proxyName, String workDirectory) {
		String jenkinsXmlFile = getJenkinsConfigFileName(getTargetDir(workDirectory, proxyName));
		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setBasicAuth(authToken);
		headers.setContentType(MediaType.TEXT_XML);

		Map<String, Object> vars = new HashMap<>();
		vars.put("proxyName", proxyName);

		UriComponents uri = UriComponentsBuilder.fromHttpUrl(jenkinsHost)
				.path(createItemUrl).buildAndExpand(vars);

		ResponseEntity<String> response = null;

		try {
			HttpEntity<byte[]> requestEntity = new HttpEntity<>(
					IOUtils.toByteArray(new FileInputStream(new File(jenkinsXmlFile))), headers);
			logger.info("Create Pipeline - Making API call to Jenkins URL : " + uri.toString());
			response = restTemplate.exchange(uri.toString(), HttpMethod.POST, requestEntity, String.class);
			logger.info("Successfully created the Jenkins pipeline");
		} catch (HttpClientErrorException httpEx) {
			System.out.println("===========================================================");
			System.out.println("Exception while calling Jenkins API");
			System.out.println("===========================================================");
			System.out.println("Status Code:" + httpEx.getStatusCode());
			System.out.println("Status:" + httpEx.getStatusText());
			System.out.println("Message:" + httpEx.getMessage());
			System.out.println("===========================================================");

			if (httpEx.getStatusCode() != null && httpEx.getStatusCode().equals(HttpStatus.BAD_REQUEST)) {
				logger.info("Skipping Jenkins pipeline creation!!!");
			} else {
				System.exit(500);
			}

		} catch (FileNotFoundException fnfEx) {
			System.out.println("Couldn't read jenkins XML config file");
			System.exit(500);
		} catch (IOException ioEx) {
			System.out.println("Exception while reading the jenkins XML config file");
			System.exit(500);
		}
		logger.debug("Response from Jenkins:" + response);
	}

	private void triggerJenkinsPipelineScan(String proxyName) {
		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setBasicAuth(authToken);
		headers.setContentType(MediaType.TEXT_XML);

		Map<String, Object> vars = new HashMap<>();
		vars.put("proxyName", proxyName);

		UriComponents uri = UriComponentsBuilder.fromHttpUrl(jenkinsHost)
				.path(pipelineScanUrl).buildAndExpand(vars);

		ResponseEntity<String> response = null;

		try {
			HttpEntity<byte[]> requestEntity = new HttpEntity<>(headers);
			logger.info("Trigger Pipeline Scan - Making API call to Jenkins URL : " + uri.toString());
			response = restTemplate.exchange(uri.toString(), HttpMethod.POST, requestEntity, String.class);
			logger.info("Successfully triggered pipeline scan");
		} catch (HttpClientErrorException httpEx) {
			System.out.println("===========================================================");
			System.out.println("Exception while calling Jenkins API");
			System.out.println("===========================================================");
			System.out.println("Status Code:" + httpEx.getStatusCode());
			System.out.println("Status:" + httpEx.getStatusText());
			System.out.println("Message:" + httpEx.getMessage());
			System.out.println("===========================================================");

			if (httpEx.getStatusCode() != null && httpEx.getStatusCode().equals(HttpStatus.BAD_REQUEST)) {
				logger.info("Skipping Jenkins pipeline trigger!!!");
			}
		}
		logger.debug("Response from Jenkins:" + response.getStatusCode());
	}

	private void untemplatize(String proxyName, String workDirectory, Map<String, Object> proxyMetadata)
			throws URISyntaxException, IOException {

		// Untemplatize
		Configuration cfg = initTemplateConfig();
		final Template template = getTemplate(cfg,
				Paths.get(workDirectory, "templates", "jenkins", "jenkinsConfigTemplate.xml"));

		String jenkinsXmlFile = getJenkinsConfigFileName(getTargetDir(workDirectory, proxyName));
		createFromTemplate(proxyMetadata, template, new File(jenkinsXmlFile));
	}

	private Configuration initTemplateConfig() {
		Configuration cfg = new Configuration(Configuration.VERSION_2_3_29);
		cfg.setDefaultEncoding("UTF-8");
		cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
		cfg.setLogTemplateExceptions(true);
		cfg.setWrapUncheckedExceptions(true);
		cfg.setFallbackOnNullLoopVariable(false);
		return cfg;
	}

	private Template getTemplate(Configuration cfg, Path src) {
		try {
			cfg.setDirectoryForTemplateLoading(src.toFile().getParentFile());
			Template template = cfg.getTemplate(src.toFile().getName());
			return template;
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Unable to create file " + src.toAbsolutePath());
			System.exit(500);
		}
		return null;
	}

	private void createFromTemplate(final Map<String, Object> proxyMetadata, Template template, File dest) {
		try (Writer file = new FileWriter(dest)) {
			template.process(proxyMetadata, file);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to create file " + dest.getAbsolutePath());
			System.exit(500);
		}
	}

	private Path getTargetDir(String workDir, String proxyName) {
		return Paths.get(workDir, proxyName, "jenkins-config");
	}

	private String getJenkinsConfigFileName(Path targetDir) {
		return Paths.get(targetDir.toString(), "jenkinsConfig.xml").toAbsolutePath().toString();
	}
}
