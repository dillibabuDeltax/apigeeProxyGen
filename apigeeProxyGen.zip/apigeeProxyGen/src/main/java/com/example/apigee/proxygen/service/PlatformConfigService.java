package com.example.apigee.proxygen.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

@Service
public class PlatformConfigService {

	@Autowired
	private CommonService commonService;
	
	@Autowired
	private GitlabService gitlabService;

	Logger logger = LoggerFactory.getLogger(PlatformConfigService.class);

	public void generatePlatformConfig() throws Exception {

		logger.info("======================================================");
		logger.info("Generating the CICD config file - platform-config-apigee");

		Map<String, Object> proxyMetadata = commonService.getProxyMetadata();
		String proxyName = commonService.getProxyName();
		String workDirectory = commonService.getWorkDirectory().toAbsolutePath().toString();

		logger.info("     ProxyName :" + proxyName);
		logger.info("     WorkDirectory:" + workDirectory);

		// Copy the jenkinsConfig template to workdir/jenkins-config
		untemplatize(proxyName, workDirectory, proxyMetadata);
		
		//Checkout platform config repo
		gitlabService.checkoutPlatformConfigRepo();
		
		//Copy over the proxy-name-version.json to platform-config-apigee directory and do the Git honors
		gitlabService.processPlatformConfigRepo(getPlatformConfigFileName(getTargetDir(workDirectory, proxyName)));

		logger.info("CICD config file generation complete");
		logger.info("====================================================== \n");
	}

	private void untemplatize(String proxyName, String workDirectory, Map<String, Object> proxyMetadata)
			throws URISyntaxException, IOException {
		
		// Create workdir/<<proxyName>>/jenkins-config to hold the XML File
		Path targetDir = getTargetDir(workDirectory, proxyName);
		Files.createDirectories(targetDir);

		// Untemplatize
		Configuration cfg = initTemplateConfig();
		final Template template = getTemplate(cfg,
				Paths.get(workDirectory, "templates", "jenkins", "platformConfigTemplate.json"));

		String platformConfigJsonFile = getPlatformConfigFileName(getTargetDir(workDirectory, proxyName));
		logger.info("Creating the ci-cd config file : " + platformConfigJsonFile);
		createFromTemplate(proxyMetadata, template, new File(platformConfigJsonFile));
	}

	private Configuration initTemplateConfig() {
		Configuration cfg = new Configuration(Configuration.VERSION_2_3_29);
		cfg.setDefaultEncoding("UTF-8");
		cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
		cfg.setLogTemplateExceptions(true);
		cfg.setWrapUncheckedExceptions(true);
		cfg.setFallbackOnNullLoopVariable(false);
		return cfg;
	}

	private Template getTemplate(Configuration cfg, Path src) {
		try {
			cfg.setDirectoryForTemplateLoading(src.toFile().getParentFile());
			Template template = cfg.getTemplate(src.toFile().getName());
			return template;
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Unable to create file " + src.toAbsolutePath());
			System.exit(500);
		}
		return null;
	}

	private void createFromTemplate(final Map<String, Object> proxyMetadata, Template template, File dest) {
		try (Writer file = new FileWriter(dest)) {
			template.process(proxyMetadata, file);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to create file " + dest.getAbsolutePath());
			System.exit(500);
		}
	}

	private Path getTargetDir(String workDir, String proxyName) {
		return Paths.get(workDir, proxyName, "jenkins-config");
	}

	private String getPlatformConfigFileName(Path targetDir) {
		return Paths.get(targetDir.toString(), commonService.getProxyName() + ".json").toAbsolutePath().toString();
	}
}
